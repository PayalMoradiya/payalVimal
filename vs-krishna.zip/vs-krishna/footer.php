<footer class="site-footer text-white ">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <aside class="widget widget_text">
          <h3 class="widget-title"><span>About Us</span></h3>

          <div class="textwidget">
            <p><img src="venders/image/vs-logo.png" class="logo-footer" /><br />
                VS Krishna Import & Export is incorporated in the year 2011 and now an established name in the business of sectors like Ferrous and Non Ferrous Scraps which is being used for the metal recycling processes in various part of the world.</p>
          </div>
        </aside>
      </div>
      

      <div class="col-xs-12 col-sm-6 col-md-4">
          <h3 class="widget-title"><span>Information</span></h3>
          <div class="menu-information-container">
              <ul class="menu" id="menu-information">
                <li><a class="menu-info" href="index.php">Home</a></li>
                <li><a class="menu-info" href="about.php">About Us</a></li>
                <li><a class="menu-info" href="non_ferrousmetalscraps.php">Products &amp; Services</a></li>
                <li><a class="menu-info" href="contact.php">Contact</a></li>
              </ul>
          </div>  
      </div>

      <div class="col-sm-6 col-md-4">  
          <h4 class="widget-title">VS KRISHNA IMPORT & EXPORT</h4>
          <div class="textwidget">
            <div class="office menu-info">
                <p>SCHONBUHL STR.46 70188, GERMANY</p>
                <p>+49 15166304514</p>
                <p>+49 15166304514</p>
                <p><a href="mailto:vskrishna@gmail.com" class="menu-info">vskrishna@gmail.com </a></p>
            </div>
          </div>
      </div>

    </div>
  </div>     
  <h6 class="text-center pb-3 menu-info">&copy Copyrights 2022 VS Krishna Import & Export.All rights reserved.</h6>   
</footer>