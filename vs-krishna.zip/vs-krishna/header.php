<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="author" content="Payal" />
    <meta name="description" content="" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"
    />
    <title>Payal Moradiya</title>
    <link href="favicon.ico.png" rel="icon" />
    
    <!--Google fonts-->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&family=Noto+Sans+JP:wght@300;400&display=swap" rel="stylesheet">
    <script src="venders/jquery/jquery-3.6.0.min.js"></script>  
    <link href="venders/bt5/css/bootstrap.min.css" rel="stylesheet" />
    <link href="libs/css/style.css" type="text/css" rel="stylesheet" />
    <link href="libs/css/slide-show.css" type="text/css" rel="stylesheet" />
    <link href="libs/css/about.css" type="text/css" rel="stylesheet" />
</head>

