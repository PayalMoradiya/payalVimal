<?php

	$cd_host = "127.0.0.1";
	$cd_port = 3308;
	$cd_socket = "";
	$cd_user = "root"; // user name
	$cd_password = "Payalvimal93"; // password
	$cd_dbname = "companydirectory"; // database name

?>