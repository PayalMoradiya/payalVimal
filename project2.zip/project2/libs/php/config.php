
<?php

//	$cd_host = "127.0.0.1";
//	$cd_port = 3308;
//	$cd_socket = "";
//	$cd_user = "root"; // user name
//	$cd_password = "Payalvimal93"; // password
//	$cd_dbname = "companydirectory"; // database name

	$cd_host = "192.168.0.100";
	$cd_port = 3306;
	$cd_user = "payalvi2_root"; // user name
	$cd_password = "Payalvimal93"; // password
	$cd_dbname = "payalvi2_companydirectory"; // database name

?>   