<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password message</title>
    <!-- custom css file link  -->
      <link rel="stylesheet" href="../css/loginSystem.css">
      <!-- Bootstrap links -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <?php 
    include_once('../includes/loginSystemHeader.php');
    ?>
    
    <!-- Message start -->
    <div class="form-container">
        <p>An email has been sent to your email address with a link to reset your password.</p>    
    </div>
    <!-- Message end -->
    
</body>
</html>