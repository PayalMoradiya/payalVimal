<?php 
$db = mysqli_connect("localhost", "root", "", "jobPortal") or die("Database is not connected!");
?>